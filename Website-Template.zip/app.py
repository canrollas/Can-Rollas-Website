from flask import Flask,render_template,flash,redirect,url_for,session,logging,request

from flask_mysqldb import MySQL

from wtforms import Form,StringField,TextAreaField,PasswordField,validators

from passlib.hash import sha256_crypt


app = Flask(__name__,static_url_path='/static',template_folder='template')
app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = "rollas"
app.config["MYSQL_DB"] = "users"
app.config["MYSQL_CURSORCLASS"]="DictCursor"
mysql = MySQL(app)


class register_form(Form):
    name = StringField("İsim Soyisim:",validators=[validators.length(min=4,max=25)])
    email=StringField("E-Mail:",validators=[validators.Email("Lütfen gecerli bir e-mail giriniz!")])
    

@app.route("/")
def index():
    number=10
    return render_template("index.html",number=number)
@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/cv")
def cv():
    return render_template("cv.html")
@app.route("/register" , methods = ["GET","POST"])
def register():

    form = register_form(request.form)

    if(request.method=="POST") and form.validate():
        
        name = form.name.data
        email = form.email.data
        cursor = mysql.connection.cursor()
        first_query="SELECT `email` FROM `users`"

        cursor.execute(first_query)
        users=cursor.fetchall()
        print("sorgu:",users)
        if((users==())):
            sorgu="INSERT INTO `users` (`id`, `name`, `email`) VALUES ('', '{}', '{}')".format(name,email)
            cursor.execute(sorgu)
            mysql.connection.commit()
            cursor.close()
            return redirect(url_for("index",data="succes"))
        else:
            return redirect(url_for("register",data="failed"))
    else:
        return render_template("register.html" ,form=form,stringer="unsucces1")




if __name__=="__main__":
    app.run(debug=True)